const ztpriceshistory = require("../models/mongodb/ztpriceshistory-model");
const ZTLABELS = require("../models/mongodb/ztlabels-model");
const ZTVALUES = require("../models/mongodb/ztvalues-model");
const mongoose = require("mongoose");

async function GetAllPricesHistory(req) {
  try {
    const idprices = parseInt(req.req.query?.idprices);
    const iniVolume = parseFloat(req.req.query?.iniVolume);
    const endVolume = parseFloat(req.req.query?.endVolume);
    let priceshistorylist;
    if (idprices >= 0) {
      priceshistorylist = await ztpriceshistory
        .findOne({ ID: idprices })
        .lean();
    } else if (iniVolume >= 0 && endVolume >= 0) {
      priceshistorylist = await ztpriceshistory
        .find({
          VOLUME: { $gte: iniVolume, $lte: endVolume },
        })
        .lean();
    } else {
      priceshistorylist = await ztpriceshistory.find().lean();
    }

    return priceshistorylist;
  } catch (error) {
    return error;
  } finally {
  }
}

//post one que llamamos add one en price history
async function AddOnePricesHistory(req) {
  try {
    //const body = req.req.body
    const newPrices = req.req.body.prices;
    //console.log(idprices)
    let priceshistorylist;

    priceshistorylist = await ztpriceshistory.insertMany(newPrices, {
      order: true,
    });
    //http://localhost:3020/api/inv/addone

    return JSON.parse(JSON.stringify(pricesHistory));
  } catch (error) {
    return error;
  } finally {
  }
}

async function UpdateOnePricesHistory(req) {
  try {
    //const body = req.req.body
    const idprices = parseInt(req.req.query?.idprices);
    const newPrices = req.req.body.prices;

    let priceshistorylist;

    priceshistorylist = await ztpriceshistory.updateMany(
      { ID: idprices },
      newPrices
    );
    //http://localhost:3020/api/inv/updateone

    return JSON.parse(JSON.stringify(pricesHistory));
  } catch (error) {
    return error;
  } finally {
  }
}

async function DeleteOnePricesHistory(req) {
  try {
    //const body = req.req.body
    const idprices = parseInt(req.req.query?.idprices);
    let priceshistorylist;
    priceshistorylist = await ztpriceshistory.deleteOne({ ID: idprices });
    //http://localhost:3020/api/inv/deleteone

    return priceshistorylist;
  } catch (error) {
    return error;
  } finally {
  }
}

async function GetAllCatalogs(req) {
  try {
    result = await mongoose.connection
        //consultas agregadas
      .collection("ZTLABELS").aggregate([
        {
            //para hacer un query de la tabla ZTLABELS 
          $lookup: {
            //Nombre de la coleccion donde se va a buscar
            from: "ZTVALUES",
            localField: "LABELID",
            foreignField: "LABELID",
            //Nombre de las coincidencias puede ser cualquier nombre
            as: "VALUES",
          },
        },
      ])
      .toArray();
    return result;
  } catch (error) {
    console.error("Error en GetAllCatalogs:", error);
    return { error: "Error al obtener los catálogos", details: error };
  }
}

async function GetCatalogByLabelId(labelId) {
  try {
    const result = await mongoose.connection
      .collection("ZTLABELS")
      .aggregate([
        {
          $match: { LABELID: labelId },
        },
        {
          $lookup: {
            from: "ZTVALUES",
            localField: "LABELID",
            foreignField: "LABELID",
            as: "VALUES",
          },
        },
      ])
      .toArray();

    // Devuelve solo el primer resultado o null si no se encontró
    return result[0] || null;
  } catch (error) {
    console.error("Error en GetCatalogByLabelId:", error);
    return { error: "Error al obtener el catálogo por LABELID", details: error };
  }
}
module.exports = {
  GetAllPricesHistory,
  AddOnePricesHistory,
  UpdateOnePricesHistory,
  DeleteOnePricesHistory,
  GetAllCatalogs,
  GetCatalogByLabelId,
};
